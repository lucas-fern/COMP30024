from referee.main import main

main()
