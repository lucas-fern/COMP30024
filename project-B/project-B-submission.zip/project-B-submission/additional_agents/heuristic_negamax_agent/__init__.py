from heuristic_negamax_agent.player import Player
