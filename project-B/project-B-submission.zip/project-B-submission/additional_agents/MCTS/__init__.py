from MCTS.player import Player
