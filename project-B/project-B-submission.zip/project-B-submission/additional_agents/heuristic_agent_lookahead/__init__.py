from heuristic_agent_lookahead.player import Player
