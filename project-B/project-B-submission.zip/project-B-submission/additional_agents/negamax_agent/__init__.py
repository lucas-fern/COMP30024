from negamax_agent.player import Player
